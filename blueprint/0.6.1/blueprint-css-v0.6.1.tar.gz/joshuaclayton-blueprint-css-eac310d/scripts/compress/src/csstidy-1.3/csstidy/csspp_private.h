/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef CSSPP_PRIVATE_H
#define CSSPP_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.3.0.2232"
#define VER_MAJOR	1
#define VER_MINOR	3
#define VER_RELEASE	0
#define VER_BUILD	2232
#define COMPANY_NAME	""
#define FILE_VERSION	"1.3"
#define FILE_DESCRIPTION	"CSS Parser and Optimiser"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	""
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"CSSTidy"
#define PRODUCT_VERSION	"1.3"

#endif /*CSSPP_PRIVATE_H*/
